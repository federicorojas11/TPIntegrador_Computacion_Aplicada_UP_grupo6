history
history -w
rm -f /root/.bash_history
journalctl --rotate
journalctl --vacuum-time=1s
apt clean
sync
poweroff
exit
lsb_release -a
apt update
ping 8.8.8.8
ping google.com
cat /etc/resolv.conf 
cat /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm main contrib non-free-firmware" > /etc/apt/sources.list
echo "deb http://security.debian.org/bookworm-security main contrib non-free-firmware" >> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm-updates main contrib non-free-firmware" >> /etc/apt/sources.list
cat /etc/apt/sources.list
sudo apt update
cat /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm main contrib non-free-firmware" > /etc/apt/sources.list
echo "deb http://security.debian.org/debian-security bookworm-security main contrib non-free-firmware" >> /etc/apt/sources.list
echo "deb http://deb.debian.org/debian bookworm-updates main contrib non-free-firmware" >> /etc/apt/sources.list
sudo apt update
sudo apt update
clear
cat /etc/apt/sources.list
sudo apt update
apt full-upgrade
lsb_release -a
ssh -v
ssh --version
which ssh
ssh --help
man ssh
ssh -V
ssh
systemctl status ssh
systemctl start ssh
apt install openssh-server
systemctl status ssh
cat /root/.ssh
cd /root/.ssh
ls
ls -la
nano
apt install nano
nano -v
clear
ls
ls -la
nano ./sshd_config
ls
cd /usr/sbin/sshd
cd /usr/sbin/ssh
cd /usr/sbin/
ls
ls
cd ..
cd ..
ls
which ssh
cd /usr/bin/
cd ssh
ls
which ssh
which sshd
cd /usr/sbin/sshd
nano /usr/sbin/sshd
clear
cd /
cd /etc/ssh
ld
ls
nano sshd_config
clear
ls
nano sshd_config
ls
/usr/sbin/sshd -t
systemctl restart ssh
systemctl status ssh
cd /root
ls
ls -la
tar -tzf /root/Material_Adicional_TPVMCA.tar.gz 
tar -xzf /root/Material_Adicional_TPVMCA.tar.gz -C /root
mkdir -p /root/.ssh
cat /root/Material_Adicional_TPVMCA/clave_publica.pub >> /root/.ssh/authorized_keys
cat /root/.ssh/authorized_keys 
ls -lat /root/.ssh/authorized_keys 
ls -lat /root/.ssh
ipconfig
ifconfig
clear
ifconfig
clear
apt install apache2 php libapache2-mod-php php-mysql
php -v
systemctl status apache2
ls
cd Material_Adicional_TPVMCA/
ls
cp ./index.php /var/www/html/
cp ./logo.png /var/www/html/
cd /var/www/
ls
cd html/
ls
cat index.php 
rm index.html
ls
tail -n 30 /var/log/apache2/error.log
clear
apt install mariadb-server
systemctl status mariadb-server
systemctl enable mariadb-server
systemctl start mariadb
systemctl enable mariadb
systemctl status mariadb
ls
cd /root/Material_Adicional_TPVMCA/
ls
cat db.sql 
mariadb
clear
mariadb -h
mariadb -v
mariadb < /root/Material_Adicional_TPVMCA/db.sql 
ifconfig
ifconfig /all
ifconfig --help
ifconfig -a
cd
cd /etc/network/
ls
cat interfaces
ifconfig
ip route
cat /etc/resolv.conf 
nano interfaces
reboot
ifconfig
ip -br address
ifup -v enp0s3
nano /etc/network/interfaces
lear
clear
nano /etc/network/interfaces
clear
reboot
nano /etc/network/interfaces
nano /etc/network/interfaces
clear
ifconfig
ip -br address
ip route
ip show
ip address
lsblk -o NAME,SIZE,TYPE,FSTYPE,MOUNTPOINTS
exit
ifconfig
nano /etc/network/interfaces
clear
cat /etc/network/interfaces
du -h
df -h
lsblk
clear
lsblk
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc1
mkfs.ext4 /dev/sdc2
ls
cd
ls
ls /
cd /
os
ls
mkdir www_dir
mkdir backup_dir
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
lsblk
cd /var/www/
cp ./html/* /www_dir/
ls /www_dir/
cd /www_dir/
ls
cat lost+found/
cd lost+found/
ls
cd
nano /etc/apache2/sites-available/000-default.conf 
nano /etc/apache2/apache2.conf 
apache2ctl configtest
systemctl reload apache2
ls
cd /var/www/
dir
cd html/
ls
cd ..
ls
rm -rf html/
cp /etc/fstab /root/fstab.old
blkid /dev/sdc1 /dev/sdc2
nano /etc/fstab 
findmnt --verify --verbose
systemctl daemon-reload
findmnt
reboot
