#!/bin/bash

PATH=/usr/sbin:/usr/bin:/sbin:/bin

if [ "$1" = "-help" ] || [ "$#" -ne 2 ]; then
    echo "Crea un backup comprimido de un directorio."
    echo
    echo "Uso: $0 ORIGEN DESTINO"
    echo "  ORIGEN:  directorio a respaldar."
    echo "  DESTINO: /backup_dir (debe estar montado)."
    echo
    echo "Ejemplo: $0 /www_dir /backup_dir"
    echo "Genera: www_dir_bkp_YYYYMMDD.tar.gz"
    echo "Nota: - No se sobrescriben backups del mismo nombre y fecha."
    exit 0
fi

origen=$(realpath -e -- "$1") || exit 1
destino=$(realpath -e -- "$2") || exit 1

# Validar directorios y montajes.
if [ ! -d "$origen" ] || [ ! -r "$origen" ] || [ ! -x "$origen" ]; then
    echo "Error: el origen no está disponible."
    exit 1
fi

if [ ! -d "$destino" ] || [ ! -w "$destino" ] || [ ! -x "$destino" ]; then
    echo "Error: el destino no está disponible."
    exit 1
fi

if [[ "$origen" == /www_dir || "$origen" == /www_dir/* ]]; then
    mountpoint -q /www_dir || {
        echo "Error: /www_dir no está montado."
        exit 1
    }
fi

if [ "$destino" != "/backup_dir" ] || ! mountpoint -q /backup_dir; then
    echo "Error: el destino debe ser /backup_dir y estar montado."
    exit 1
fi

if [[ "$origen" == / || "$destino" == "$origen" || "$destino" == "$origen/"* ]]; then
    echo "Error: el destino está dentro del origen."
    exit 1
fi

# Crear el backup con fecha.
fecha=$(date +%Y%m%d)
nombre=$(basename "$origen")
archivo="$destino/${nombre}_bkp_${fecha}.tar.gz"

if [ -e "$archivo" ]; then
    echo "Error: ya existe $archivo"
    exit 1
fi

tar -czf "$archivo" -C "$(dirname "$origen")" "$nombre"
estado=$?

if [ "$estado" -eq 0 ]; then
    echo "Backup completado: $archivo"
else
    echo "Backup con advertencias o errores. Revisar los mensajes de tar."
fi

exit "$estado"
